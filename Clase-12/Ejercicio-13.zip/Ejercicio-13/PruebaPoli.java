public class PruebaPoli{
    public static void main (String[] args) {
        PoligonoIrreg poligonoIrreg = new PoligonoIrreg();
     
        //Imprimimos los valores
        System.out.println(poligonoIrreg);
        poligonoIrreg.ordenaVertices();
        System.out.println(poligonoIrreg);
    }
}